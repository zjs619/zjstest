import React , {Component} from 'react';
import '../assets/css/index.css'


class News extends Component {
    constructor(props) {
        super(props);
        this.state = {  
        };
    }
    render() {
        return (
            <div>
                这是新闻组件
            </div>

        );
    }
}

export default News;